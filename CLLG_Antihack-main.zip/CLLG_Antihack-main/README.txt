THANKS FOR DOWNLOADING CCLG
REMEMBER TO CREDIT THE AUTHOR IF YOU'RE RECORDING THE USAGE OF THE PROGRAM
ENJOY!

#NoMoreHackers

INSTRUCTIONS
----------------------------------------------------------------------------------

1- Open the .exe program
2- When it checks a folder it will stop until you give it access into the next one so click anything to continue when needed
3- Once the program closes you can go to your Documents folder and you'll see a folder with the logs/results of the check
4- Read them with your code viewer of preference like VisualStudioCode or Notepad++
5- You've finished
----------------------------------------------------------------------------------